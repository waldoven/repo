
-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(10) UNSIGNED NOT NULL,
  `nom_cliente` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `rut_cliente` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `giro_cliente` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `dire_cliente` varchar(80) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `comuna_cliente` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `ciudad_cliente` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `correo_cliente` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `telef_cliente` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `contac_cliente` varchar(80) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nom_cliente`, `rut_cliente`, `giro_cliente`, `dire_cliente`, `comuna_cliente`, `ciudad_cliente`, `correo_cliente`, `telef_cliente`, `contac_cliente`) VALUES
(0, 'EMPRESA DE CAMIONES 2', '12344444-9', 'Agricola', 'Callle 5 #42', 'Lampa', 'Chillan', 'a@update.com', '55555555555555', 'Juan Rodriguez'),
(0, 'EMPRESA DE CAMIONES', '123456-7', 'Construccion', 'Avenida 4 casa 3', 'La Reina', 'Chillan', 'empresa@gmail.com', '912345678', 'Pedro Perez'),
(0, 'LA GRAN REPARADORA DE VEHICULO', '12345678-9', 'TALLER', 'Avenida Los Pelados 20123 Camino a Lonquen', 'Cerro Navia', 'Santiago', 'greppa@gmail.com', '912345678', 'Pedro Perez Alfonso'),
(0, 'SARA', '23185226-2', 'Retail', 'Callle 5 #00', 'Lampa', 'Santiago', 'sara@gmail.com', '99912345678', 'Aldo'),
(0, 'EMPRESA DE CAMIONES 3', '234567890-9', 'Ganaderia', 'Callle 5 #0088', 'Las Palmas', 'Osorno', 'empresa@gmail.com', '111111111111111', 'Juan Rodriguez'),
(0, 'EMPRESA DE CAMIONES 4', '345678912-1', 'Pescaderia', 'calle cauquenes 60 casa 45', 'Machali', 'Ancud', 'greppa@gmail.com', '3333333333', 'Pedro Perez'),
(0, 'REPARADORA DE VEHICULOS 1', '4455667788-9', 'Construccion', 'Avenida Los Pelados 20123 Camino a Lonquen', 'La Reina', 'Osorno', 'a@php.com', '55555555555555', 'Juan Rodriguez'),
(0, 'REPO', '6273643-0', 'Mineria', 'Callle 5 #11', 'Ñuñoa', 'Santiago', 'a@a.com', '3333333333', 'Daphne'),
(0, 'REPO1', '6273643-1', 'Mineria', 'Callle 5 #111', 'Ñuñoa', 'Santiago', 'a@update.com', '111111111111111', 'Pedro Perez'),
(0, 'REPO2', '6273643-2', 'Mineria', 'Callle 5 #11', 'Ñuñoa', 'Santiago', 'abc@a.com', '99999999', 'Daphne'),
(0, 'REPO4', '6273643-4', 'Mineria', 'Callle 5 #111', 'Ñuñoa', 'Santiago', 'a@update.com', '3333333333', 'Daphne'),
(0, 'REPO5', '6273643-5', 'Mineria', 'Callle 5 #00', 'Ñuñoa', 'Santiago', 'a@update.com', '00000000000', 'Daphne'),
(0, 'ALDO', '6373643-0', 'Retail', 'calle cauquenes 60 casa 45', 'Ñuñoa', 'Santiago', 'aldo@gmail.com', '912345678', 'Pedro Perez');
