
-- --------------------------------------------------------

--
-- Table structure for table `cotizaciones`
--

CREATE TABLE `cotizaciones` (
  `rut_cliente` varchar(11) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `num_cotizacion` int(10) NOT NULL,
  `fecha_cotizacion` date NOT NULL,
  `codigo_parte` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(3) NOT NULL,
  `userid` varchar(4) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cotizaciones`
--

INSERT INTO `cotizaciones` (`rut_cliente`, `num_cotizacion`, `fecha_cotizacion`, `codigo_parte`, `cantidad`, `userid`) VALUES
('6373643-0', 201905251, '2019-05-25', 'COMP0123456789', 10, '4'),
('123456-7', 201905252, '2019-05-25', 'COMP0123456789', 1, '4'),
('123456-7', 201905252, '2019-05-25', 'CORR123456k8', 2, '4'),
('123456-7', 201905252, '2019-05-25', 'CORREA12345', 3, '4'),
('123456-7', 201905252, '2019-05-25', 'ff324rf11', 4, '4'),
('123456-7', 201905252, '2019-05-25', 'ff324rf16', 5, '4'),
('123456-7', 201905252, '2019-05-25', 'KK2345', 6, '4'),
('123456-7', 201905252, '2019-05-25', 'MB160948', 7, '4');
