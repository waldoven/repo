
-- --------------------------------------------------------

--
-- Table structure for table `partes`
--

CREATE TABLE `partes` (
  `marca` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `modelo` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `tipo_rep` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `cod_tiporep` varchar(3) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `vin` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `codigo` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `costo` decimal(15,2) NOT NULL,
  `valor` decimal(15,2) NOT NULL,
  `valor1` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `partes`
--

INSERT INTO `partes` (`marca`, `modelo`, `tipo_rep`, `cod_tiporep`, `vin`, `codigo`, `descripcion`, `costo`, `valor`, `valor1`) VALUES
('OPEL', 'CORSA', 'compresor', '', NULL, 'COMP0123456789', 'compresor', '25000.00', '30000.00', '180.00'),
('FORD', 'Spark', 'correa compresor', '', NULL, 'CORR123456k8', 'correa compresos', '12300.00', '23400.00', '345.00'),
('SSANGYONG', 'SSmaYong', 'correa alternador', '', NULL, 'CORREA12345', 'correa 1', '12345.00', '23456.00', '34567.00'),
('CHRYSLER', '123', 'cremallera', '', NULL, 'ff324rf11', 'correa', '19000.00', '20000.00', '7890.00'),
('AUDI', '12', 'adhesivo', '', NULL, 'ff324rf16', 'correa', '1234.00', '180000.00', '7890.00'),
('KIA', 'RIO', 'bocina', '', NULL, 'KK2345', 'bocina bomba de agua', '45000.00', '90000.00', '85.00'),
('CHEVROLET', 'DMAX', 'parachoque', '047', '0123456789', 'MB160948', 'PARACHOQUE DELANTERO DMAX RT50 2015', '1111.00', '20.00', '10000.00'),
('SUZUKI', 'SWIFT', 'optico', '', NULL, 'OPT4567890', 'optico', '123.00', '234.00', '267.00'),
('VOLKSWAGEN', 'BEETLE', 'turbo', '', NULL, 'VW12345K789', 'turbo alimentador', '46.00', '120.00', '90.00');
