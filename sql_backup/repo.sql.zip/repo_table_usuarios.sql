
-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `username` varchar(15) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `rol` varchar(50) NOT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `password`, `rol`, `created`) VALUES
(4, 'Aldo', '$2y$10$cchi6YpM4aAV24EeBPdFmOni0Wl013A8PtUQVZ0/wtQaGbIpdQBzu', 'Administrador', '2019-05-13 16:15:52'),
(6, 'Diego', '$2y$10$CQZUjGNlTXrAmhgyMlhrwu6a1SxRKpVRaYTlwJ9Zo82YaN8iMC2hq', 'Administrador', '2019-05-19 21:24:48'),
(7, 'Daphne', '$2y$10$VVs81zmEljShXYCZjdy.QuKulvlTvslkIB..fcjG.QNvwQwWh0Tam', 'Vendedor', '2019-05-19 21:31:57'),
(8, 'Sara', '$2y$10$t7REaUcSgp6/j8IoXZSxJ.Uc9AFpbTseK6cVw.8yu.t2TfkS3SW4S', 'Vendedor', '2019-05-21 12:25:48');
