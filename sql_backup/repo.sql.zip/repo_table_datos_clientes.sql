
-- --------------------------------------------------------

--
-- Table structure for table `datos_clientes`
--

CREATE TABLE `datos_clientes` (
  `id_cliente` int(10) NOT NULL,
  `direccion` varchar(50) CHARACTER SET ascii NOT NULL,
  `comuna` varchar(20) CHARACTER SET ascii NOT NULL,
  `ciudad` varchar(30) CHARACTER SET ascii NOT NULL,
  `email` varchar(30) CHARACTER SET ascii NOT NULL,
  `telefono` varchar(20) CHARACTER SET ascii NOT NULL,
  `contacto` varchar(30) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datos_clientes`
--

INSERT INTO `datos_clientes` (`id_cliente`, `direccion`, `comuna`, `ciudad`, `email`, `telefono`, `contacto`) VALUES
(0, 'Alicia Cursi', 'acursi@gmail.com', '123456789', '', '', ''),
(0, 'Pelayo Perezon', 'jaavila@cantv.net', '+56 976543321', '', '', ''),
(0, 'Waldo Silva Melendez', 'francisquiva@gmail.c', '999999999', '', '', '');
