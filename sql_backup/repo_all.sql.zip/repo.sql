-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2019 at 11:09 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `repo`
--
CREATE DATABASE IF NOT EXISTS `repo` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `repo`;

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(10) UNSIGNED NOT NULL,
  `nom_cliente` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `rut_cliente` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `giro_cliente` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `dire_cliente` varchar(80) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `comuna_cliente` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `ciudad_cliente` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `correo_cliente` varchar(40) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `telef_cliente` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `contac_cliente` varchar(80) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nom_cliente`, `rut_cliente`, `giro_cliente`, `dire_cliente`, `comuna_cliente`, `ciudad_cliente`, `correo_cliente`, `telef_cliente`, `contac_cliente`) VALUES
(0, 'EMPRESA DE CAMIONES 2', '12344444-9', 'Agricola', 'Callle 5 #42', 'Lampa', 'Chillan', 'a@update.com', '55555555555555', 'Juan Rodriguez'),
(0, 'EMPRESA DE CAMIONES', '123456-7', 'Construccion', 'Avenida 4 casa 3', 'La Reina', 'Chillan', 'empresa@gmail.com', '912345678', 'Pedro Perez'),
(0, 'LA GRAN REPARADORA DE VEHICULO', '12345678-9', 'TALLER', 'Avenida Los Pelados 20123 Camino a Lonquen', 'Cerro Navia', 'Santiago', 'greppa@gmail.com', '912345678', 'Pedro Perez Alfonso'),
(0, 'SARA', '23185226-2', 'Retail', 'Callle 5 #00', 'Lampa', 'Santiago', 'sara@gmail.com', '99912345678', 'Aldo'),
(0, 'EMPRESA DE CAMIONES 3', '234567890-9', 'Ganaderia', 'Callle 5 #0088', 'Las Palmas', 'Osorno', 'empresa@gmail.com', '111111111111111', 'Juan Rodriguez'),
(0, 'EMPRESA DE CAMIONES 4', '345678912-1', 'Pescaderia', 'calle cauquenes 60 casa 45', 'Machali', 'Ancud', 'greppa@gmail.com', '3333333333', 'Pedro Perez'),
(0, 'REPARADORA DE VEHICULOS 1', '4455667788-9', 'Construccion', 'Avenida Los Pelados 20123 Camino a Lonquen', 'La Reina', 'Osorno', 'a@php.com', '55555555555555', 'Juan Rodriguez'),
(0, 'REPO', '6273643-0', 'Mineria', 'Callle 5 #11', 'Ñuñoa', 'Santiago', 'a@a.com', '3333333333', 'Daphne'),
(0, 'REPO1', '6273643-1', 'Mineria', 'Callle 5 #111', 'Ñuñoa', 'Santiago', 'a@update.com', '111111111111111', 'Pedro Perez'),
(0, 'REPO2', '6273643-2', 'Mineria', 'Callle 5 #11', 'Ñuñoa', 'Santiago', 'abc@a.com', '99999999', 'Daphne'),
(0, 'REPO4', '6273643-4', 'Mineria', 'Callle 5 #111', 'Ñuñoa', 'Santiago', 'a@update.com', '3333333333', 'Daphne'),
(0, 'REPO5', '6273643-5', 'Mineria', 'Callle 5 #00', 'Ñuñoa', 'Santiago', 'a@update.com', '00000000000', 'Daphne'),
(0, 'ALDO', '6373643-0', 'Retail', 'calle cauquenes 60 casa 45', 'Ñuñoa', 'Santiago', 'aldo@gmail.com', '912345678', 'Pedro Perez');

-- --------------------------------------------------------

--
-- Table structure for table `cotizaciones`
--

CREATE TABLE `cotizaciones` (
  `rut_cliente` varchar(11) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `num_cotizacion` int(10) NOT NULL,
  `fecha_cotizacion` date NOT NULL,
  `codigo_parte` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(3) NOT NULL,
  `userid` varchar(4) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cotizaciones`
--

INSERT INTO `cotizaciones` (`rut_cliente`, `num_cotizacion`, `fecha_cotizacion`, `codigo_parte`, `cantidad`, `userid`) VALUES
('6373643-0', 201905251, '2019-05-25', 'COMP0123456789', 10, '4'),
('123456-7', 201905252, '2019-05-25', 'COMP0123456789', 1, '4'),
('123456-7', 201905252, '2019-05-25', 'CORR123456k8', 2, '4'),
('123456-7', 201905252, '2019-05-25', 'CORREA12345', 3, '4'),
('123456-7', 201905252, '2019-05-25', 'ff324rf11', 4, '4'),
('123456-7', 201905252, '2019-05-25', 'ff324rf16', 5, '4'),
('123456-7', 201905252, '2019-05-25', 'KK2345', 6, '4'),
('123456-7', 201905252, '2019-05-25', 'MB160948', 7, '4');

-- --------------------------------------------------------

--
-- Table structure for table `datos_clientes`
--

CREATE TABLE `datos_clientes` (
  `id_cliente` int(10) NOT NULL,
  `direccion` varchar(50) CHARACTER SET ascii NOT NULL,
  `comuna` varchar(20) CHARACTER SET ascii NOT NULL,
  `ciudad` varchar(30) CHARACTER SET ascii NOT NULL,
  `email` varchar(30) CHARACTER SET ascii NOT NULL,
  `telefono` varchar(20) CHARACTER SET ascii NOT NULL,
  `contacto` varchar(30) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datos_clientes`
--

INSERT INTO `datos_clientes` (`id_cliente`, `direccion`, `comuna`, `ciudad`, `email`, `telefono`, `contacto`) VALUES
(0, 'Alicia Cursi', 'acursi@gmail.com', '123456789', '', '', ''),
(0, 'Pelayo Perezon', 'jaavila@cantv.net', '+56 976543321', '', '', ''),
(0, 'Waldo Silva Melendez', 'francisquiva@gmail.c', '999999999', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `marcas`
--

CREATE TABLE `marcas` (
  `marca` varchar(20) NOT NULL,
  `sigla` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marcas`
--

INSERT INTO `marcas` (`marca`, `sigla`) VALUES
('MITSUBISHI', 'MM'),
('TOYOTA', 'TY'),
('CHEVROLET', 'CH'),
('SSANGYONG', 'SY'),
('PEUEGEOT', 'PG'),
('CITROEN', 'CT'),
('FORD', 'FD'),
('SUBARU', 'SB'),
('AUDI', 'AU'),
('MERCEDES', 'MB'),
('HONDA', 'HO'),
('HYUNDAI', 'HY'),
('KIA', 'KI'),
('VOLVO', 'VL'),
('MAZDA', 'MZ'),
('VOLKSWAGEN', 'VW'),
('SUZUKI', 'SZ'),
('CHRYSLER', 'CS'),
('DODGE', 'DG'),
('FIAT', 'FT'),
('JEEP', 'JE'),
('MAHINDRA', 'MH'),
('MG', 'MG'),
('OPEL', 'OP'),
('RENAULT', 'RL'),
('SAMSUNG', 'SM');

-- --------------------------------------------------------

--
-- Table structure for table `partes`
--

CREATE TABLE `partes` (
  `marca` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `modelo` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `tipo_rep` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `cod_tiporep` varchar(3) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `vin` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `codigo` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `costo` decimal(15,2) NOT NULL,
  `valor` decimal(15,2) NOT NULL,
  `valor1` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `partes`
--

INSERT INTO `partes` (`marca`, `modelo`, `tipo_rep`, `cod_tiporep`, `vin`, `codigo`, `descripcion`, `costo`, `valor`, `valor1`) VALUES
('OPEL', 'CORSA', 'compresor', '', NULL, 'COMP0123456789', 'compresor', '25000.00', '30000.00', '180.00'),
('FORD', 'Spark', 'correa compresor', '', NULL, 'CORR123456k8', 'correa compresos', '12300.00', '23400.00', '345.00'),
('SSANGYONG', 'SSmaYong', 'correa alternador', '', NULL, 'CORREA12345', 'correa 1', '12345.00', '23456.00', '34567.00'),
('CHRYSLER', '123', 'cremallera', '', NULL, 'ff324rf11', 'correa', '19000.00', '20000.00', '7890.00'),
('AUDI', '12', 'adhesivo', '', NULL, 'ff324rf16', 'correa', '1234.00', '180000.00', '7890.00'),
('KIA', 'RIO', 'bocina', '', NULL, 'KK2345', 'bocina bomba de agua', '45000.00', '90000.00', '85.00'),
('CHEVROLET', 'DMAX', 'parachoque', '047', '0123456789', 'MB160948', 'PARACHOQUE DELANTERO DMAX RT50 2015', '1111.00', '20.00', '10000.00'),
('SUZUKI', 'SWIFT', 'optico', '', NULL, 'OPT4567890', 'optico', '123.00', '234.00', '267.00'),
('VOLKSWAGEN', 'BEETLE', 'turbo', '', NULL, 'VW12345K789', 'turbo alimentador', '46.00', '120.00', '90.00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `description` text NOT NULL,
  `price` double NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `created`, `modified`) VALUES
(1, 'Basketball', 'A ball used in the NBA.', 49.99, '2015-08-02 12:04:03', '2015-08-06 09:59:18'),
(3, 'Gatorade', 'This is a very good drink for athletes.', 1.99, '2015-08-02 12:14:29', '2015-08-06 09:59:18'),
(4, 'Eye Glasses', 'It will make you read better.', 6, '2015-08-02 12:15:04', '2015-08-06 09:59:18'),
(5, 'Trash Can', 'It will help you maintain cleanliness.', 3.95, '2015-08-02 12:16:08', '2015-08-06 09:59:18'),
(6, 'Mouse', 'Very useful if you love your computer.', 11.35, '2015-08-02 12:17:58', '2015-08-06 09:59:18'),
(7, 'Earphone', 'You need this one if you love music.', 7, '2015-08-02 12:18:21', '2015-08-06 09:59:18'),
(8, 'Pillow', 'Sleeping well is important.', 8.99, '2015-08-02 12:18:56', '2015-08-06 09:59:18');

-- --------------------------------------------------------

--
-- Table structure for table `tiporepuesto`
--

CREATE TABLE `tiporepuesto` (
  `tipo_rep` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `cod_tipo_rep` varchar(3) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tiporepuesto`
--

INSERT INTO `tiporepuesto` (`tipo_rep`, `cod_tipo_rep`) VALUES
('adhesivo', '001'),
('amortiguador', '002'),
('antena', '003'),
('axial', '004'),
('balatas', '005'),
('bandeja', '006'),
('bieleta', '007'),
('bobina', '008'),
('bocina', '009'),
('bomba direccion', '010'),
('bomba agua', '011'),
('bomba freno', '012'),
('brazo direccion', '013'),
('buje', '014'),
('cazoleta', '015'),
('cilindro freno', '016'),
('compresor', '017'),
('correa alternador', '018'),
('correa compresor', '019'),
('cremallera', '020'),
('culata', '021'),
('deposito', '022'),
('disco', '023'),
('espejo', '024'),
('extremo direccion', '025'),
('eyector', '026'),
('filtro aire', '027'),
('filtro aceite', '028'),
('filtro cabina', '029'),
('filtro petroleo', '030'),
('filtro decantador', '031'),
('foco', '032'),
('guardafango', '033'),
('guia parachoque', '034'),
('intercooler', '035'),
('inyector', '036'),
('kit embrague', '037'),
('kit distribucion', '038'),
('llanta', '039'),
('llave', '040'),
('mascara', '041'),
('maza', '042'),
('moldura', '043'),
('neblinero', '044'),
('optico', '045'),
('paquete resorte', '046'),
('parachoque', '047'),
('pastillas', '048'),
('perno rueda', '049'),
('piola freno', '050'),
('plumillas', '051'),
('puerta', '052'),
('punta homocinetica', '053'),
('radiador', '054'),
('reflectante', '055'),
('regulador', '056'),
('rodamiento homocinet', '057'),
('rodamiento cazoleta', '058'),
('rodamiento embrague', '059'),
('rodamiento maza', '060'),
('rotula', '061'),
('sensor abs', '062'),
('set', '063'),
('soporte cardan', '064'),
('soporte vidrio', '065'),
('tambor', '066'),
('tapabarro', '067'),
('tecle', '068'),
('tensor', '069'),
('terminal', '070'),
('tuerca', '071'),
('turbo', '072'),
('volante', '073'),
('sensor ckp', '074'),
('rejilla', '075');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `username` varchar(15) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `rol` varchar(50) NOT NULL,
  `created` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `password`, `rol`, `created`) VALUES
(4, 'Aldo', '$2y$10$cchi6YpM4aAV24EeBPdFmOni0Wl013A8PtUQVZ0/wtQaGbIpdQBzu', 'Administrador', '2019-05-13 16:15:52'),
(6, 'Diego', '$2y$10$CQZUjGNlTXrAmhgyMlhrwu6a1SxRKpVRaYTlwJ9Zo82YaN8iMC2hq', 'Administrador', '2019-05-19 21:24:48'),
(7, 'Daphne', '$2y$10$VVs81zmEljShXYCZjdy.QuKulvlTvslkIB..fcjG.QNvwQwWh0Tam', 'Vendedor', '2019-05-19 21:31:57'),
(8, 'Sara', '$2y$10$t7REaUcSgp6/j8IoXZSxJ.Uc9AFpbTseK6cVw.8yu.t2TfkS3SW4S', 'Vendedor', '2019-05-21 12:25:48');

-- --------------------------------------------------------

--
-- Table structure for table `ventas`
--

CREATE TABLE `ventas` (
  `rut_cliente` varchar(11) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `num_venta` int(10) NOT NULL,
  `fecha_venta` date NOT NULL,
  `codigo_parte` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `cantidad` int(3) NOT NULL,
  `userid` varchar(4) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ventas`
--

INSERT INTO `ventas` (`rut_cliente`, `num_venta`, `fecha_venta`, `codigo_parte`, `cantidad`, `userid`) VALUES
('6273643-5', 201905214, '2019-05-21', 'COMP0123456789', 1, '4'),
('6273643-5', 201905214, '2019-05-21', 'ff324rf11', 3, '4'),
('6273643-5', 201905214, '2019-05-21', 'CORR123456k8', 2, '4'),
('6273643-5', 201905214, '2019-05-21', 'ff324rf16', 4, '4'),
('6273643-5', 201905214, '2019-05-21', 'KK2345', 5, '4'),
('6273643-5', 201905214, '2019-05-21', 'MB160948', 6, '4'),
('6273643-5', 201905214, '2019-05-21', 'OPT4567890', 7, '4'),
('6273643-5', 201905214, '2019-05-21', 'VW12345K789', 8, '4'),
('12345678-9', 201905231, '2019-05-23', 'COMP0123456789', 10, '4'),
('12345678-9', 201905231, '2019-05-23', 'CORR123456k8', 20, '4'),
('12345678-9', 201905231, '2019-05-23', 'ff324rf16', 30, '4'),
('12345678-9', 201905231, '2019-05-23', 'KK2345', 40, '4'),
('123456-7', 201905252, '2019-05-25', 'ff324rf11', 11, '4'),
('345678912-1', 201905253, '2019-05-25', 'MB160948', 23, '4'),
('234567890-9', 201905254, '2019-05-25', 'CORREA12345', 5, '4'),
('12344444-9', 201905255, '2019-05-25', 'COMP0123456789', 1, '4'),
('12344444-9', 201905255, '2019-05-25', 'CORR123456k8', 2, '4'),
('12344444-9', 201905255, '2019-05-25', 'CORREA12345', 3, '4'),
('12344444-9', 201905255, '2019-05-25', 'ff324rf11', 4, '4'),
('12344444-9', 201905255, '2019-05-25', 'ff324rf16', 6, '4'),
('12344444-9', 201905255, '2019-05-25', 'KK2345', 7, '4'),
('12344444-9', 201905255, '2019-05-25', 'MB160948', 8, '4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`rut_cliente`);

--
-- Indexes for table `partes`
--
ALTER TABLE `partes`
  ADD PRIMARY KEY (`codigo`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tiporepuesto`
--
ALTER TABLE `tiporepuesto`
  ADD PRIMARY KEY (`cod_tipo_rep`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
